@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('All Category Page'))

@push('css_or_js')
    <meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="og:title" content="Categories of {{$web_config['name']->value}} "/>
    <meta property="og:url" content="{{env('APP_URL')}}">
    <meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="twitter:title" content="Categories of {{$web_config['name']->value}}"/>
    <meta property="twitter:url" content="{{env('APP_URL')}}">
    <meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">
    
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/new-css.css"/>
    
    <style>
        .sub-cat-img {
            margin-bottom: 20px;
        }

        .budget-deal-inner,
        .best-seller-inner{
            margin-top: 10px;
        }

        .brand-name {
            text-transform: uppercase;
            font-weight: 600;
        }

        .flash-product-title {
            font-size: 15px;
        }
        
        .product-card .product-detail{
            padding-left: 10px;
            padding-right: 10px;
        }
        
        @media (min-width: 360px) and (max-width: 575px){
            .banner-section img{
                height: 170px;
            }
        }
    </style>

@endpush

@section('content')
   
    <!-- Page Content-->
    
    <div class="banner-section">
        <img src="https://accezory.in/storage/app/public/deal/2022-12-04-638ca050d4543.png" class="w-100" alt="">
    </div>
    
    <div class="container-fluid mt-2">
        <div class="budget-deal">
            <div class="title">
                <span class="budget-deal-title" style="font-size:20px !important; font-weight:700">Budget Deals</span>
            </div>
            
            <div class="budget-deal-inner">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-3 col-sm-4 col-4">
                    <div class="sub-cat-img">
                        <img src="https://demo.accezory.in/public/assets/front-end/img/budget-img/1.jpg" class="w-100" alt="">
                    </div>
                </div>
                
                
            </div>
            </div>
        </div>
        <div class="ex-best-seller">
            <div class="title">
                <span class="budget-deal-title" style="font-size:20px !important; font-weight:700">Explore Best Sellers</span>
            </div>
            <div class="best-seller-inner">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-3">
                    <div class="product-single-hover product-card">
                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">

                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                <a href="https://accezory.in/product/accezory-tan-artificial-leather-wallet-7jOPAf">
                                    <img src="https://accezory.in/storage/app/public/product/thumbnail/2022-07-12-62cdba21aec2a.png" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                </a>
                            </div>
                        </div>
                        <div class="product-detail d-flex align-items-center">
                            <div>
                               <div class="brand-name">Accezory</div>
                                <div>
                                    <span class="flash-product-title">
                                        Men Brown Genuine Leather Wallet
                                    </span>
                                </div>
                                <div class="flash-product-review">
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <label class="badge-style2">
                                        ( 3 )
                                    </label>
                                </div>
                                <div>

                                </div>
                                <div class="flash-product-price">
                                    <span class="real-price" style="font-weight: 600">₹269.1</span>
                                    <strike class="strikr-price" style="color: #9b9b9b !important;">
                                        ₹299.0
                                    </strike>
                                    <span class="o-price" style="color: #E96A6A!important; font-weight: 600">
                                        65%
                                        Off
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-3">
                    <div class="product-single-hover product-card">
                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
<!--
                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                <span class="for-discoutn-value p-1 pl-2 pr-2">
                                    ON SALE
                                </span>
                            </div>
-->
                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                <a href="https://accezory.in/product/accezory-tan-artificial-leather-wallet-7jOPAf">
                                    <img src="https://accezory.in/storage/app/public/product/thumbnail/2022-07-12-62cdba21aec2a.png" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                </a>
                            </div>
                        </div>
                        <div class="product-detail d-flex align-items-center">
                            <div>
                               <div class="brand-name">Accezory</div>
                                <div>
                                    <span class="flash-product-title">
                                        Men Brown Genuine Leather Wallet
                                    </span>
                                </div>
                                <div class="flash-product-review">
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <label class="badge-style2">
                                        ( 3 )
                                    </label>
                                </div>
                                <div>

                                </div>
                                <div class="flash-product-price">
                                    <span class="real-price" style="font-weight: 600">₹269.1</span>
                                    <strike class="strikr-price" style="color: #9b9b9b !important;">
                                        ₹299.0
                                    </strike>
                                    <span class="o-price" style="color: #E96A6A!important; font-weight: 600">
                                        65%
                                        Off
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-3">
                    <div class="product-single-hover product-card">
                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
<!--
                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                <span class="for-discoutn-value p-1 pl-2 pr-2">
                                    ON SALE
                                </span>
                            </div>
-->
                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                <a href="https://accezory.in/product/accezory-tan-artificial-leather-wallet-7jOPAf">
                                    <img src="https://accezory.in/storage/app/public/product/thumbnail/2022-07-12-62cdba21aec2a.png" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                </a>
                            </div>
                        </div>
                        <div class="product-detail d-flex align-items-center">
                            <div>
                               <div class="brand-name">Accezory</div>
                                <div>
                                    <span class="flash-product-title">
                                        Men Brown Genuine Leather Wallet
                                    </span>
                                </div>
                                <div class="flash-product-review">
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <label class="badge-style2">
                                        ( 3 )
                                    </label>
                                </div>
                                <div>

                                </div>
                                <div class="flash-product-price">
                                    <span class="real-price" style="font-weight: 600">₹269.1</span>
                                    <strike class="strikr-price" style="color: #9b9b9b !important;">
                                        ₹299.0
                                    </strike>
                                    <span class="o-price" style="color: #E96A6A!important; font-weight: 600">
                                        65%
                                        Off
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-3">
                    <div class="product-single-hover product-card">
                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
<!--
                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                <span class="for-discoutn-value p-1 pl-2 pr-2">
                                    ON SALE
                                </span>
                            </div>
-->
                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                <a href="https://accezory.in/product/accezory-tan-artificial-leather-wallet-7jOPAf">
                                    <img src="https://accezory.in/storage/app/public/product/thumbnail/2022-07-12-62cdba21aec2a.png" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                </a>
                            </div>
                        </div>
                        <div class="product-detail d-flex align-items-center">
                            <div>
                               <div class="brand-name">Accezory</div>
                                <div>
                                    <span class="flash-product-title">
                                        Men Brown Genuine Leather Wallet
                                    </span>
                                </div>
                                <div class="flash-product-review">
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <label class="badge-style2">
                                        ( 3 )
                                    </label>
                                </div>
                                <div>

                                </div>
                                <div class="flash-product-price">
                                    <span class="real-price" style="font-weight: 600">₹269.1</span>
                                    <strike class="strikr-price" style="color: #9b9b9b !important;">
                                        ₹299.0
                                    </strike>
                                    <span class="o-price" style="color: #E96A6A!important; font-weight: 600">
                                        65%
                                        Off
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        $(document).ready(function () {
            $('.card-header').click(function() {
                $('.card-header').removeClass('active');
                $(this).addClass('active');
            });

        });
        function get_categories(route) {
            $.get({
                url: route,
                dataType: 'json',
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (response) {
                    $('html,body').animate({scrollTop: $("#ajax-categories").offset().top}, 'slow');
                    $('#ajax-categories').html(response.view);
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        }
    </script>
@endpush
