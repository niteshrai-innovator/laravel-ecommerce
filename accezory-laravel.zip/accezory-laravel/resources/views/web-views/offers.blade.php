@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('Offers'))

@push('css_or_js')
    <meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="og:title" content="Categories of {{$web_config['name']->value}} "/>
    <meta property="og:url" content="{{env('APP_URL')}}">
    <meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="twitter:title" content="Categories of {{$web_config['name']->value}}"/>
    <meta property="twitter:url" content="{{env('APP_URL')}}">
    <meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">
 <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/new-css.css"/>
      
<link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.carousel.min.css"/>
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.theme.default.min.css"/>
    
    <style>
        .sub-cat-img {
            margin-bottom: 10px;
        }

/*
        .budget-deal-inner,
        .best-seller-inner{
            margin-top: 10px;
        }
*/
        
        .flash-product-title{
            font-size: 15px;
        }

        .brand-name {
            text-transform: uppercase;
            font-weight: 600;
        }
        
        .title{
            margin-bottom: 10px;
        }

        .budget-deal-title {
            font-size: 20px;
            text-transform: uppercase;
        }
        
        .product-card .product-detail{
            padding-left: 10px;
            padding-right: 10px;
        }
        
        .deal-offer{
            background: #f10e5d;
            padding: 30px;
        }
        
        .deal-off-title{
            color: #fff;
            font-weight: 700;
        }
        
        .deal-offer .deal-desc p{
            color: #fff;
            font-size: 14px;
            margin: 0px;
        }
        
        .dis-per{
            background: #fff;
            border: 1px dashed #c8252b;
            text-align: center;
            padding: 12px 0px;
        }
        
        .dis-per h6{
            text-transform: uppercase;
            font-weight: 500;
            color: #c8252b;
            font-size: 14px;
            margin: 0px;
            margin-bottom: 5px !important;
        }
        
        .dis-per p{
            color: #c8252b;
            margin: 0px;
            font-size: 30px;
            font-weight: 700;
            line-height: 1;
        }
        
        @media (min-width: 360px) and (max-width: 575px){
            .category-product-view-all, .latest-product-view-all {
                padding-top: 0px !important;
            }

            .budget-deal-title{
                font-size: 16px !important;
            }
            
            .banner-section img{
                height: 170px;
        }
            
            .offer-selling .owl-carousel .owl-item{
                height: 175px !important;
            }
            
            .deal-offer{
                padding: 15px;
            }
        
        @media (min-width: 320px) and (max-width: 991px) {
            .dis-per{
                margin-top: 10px;
            }
        }
    </style>
   
@endpush

@section('content')
    <!-- Page Content-->
    <div class="banner-section">
        <img class="d-block w-100" style="height: 353px;" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" src="https://accezory.in/storage/app/public/deal/2022-12-04-638ca050d4543.png" alt="">
    </div>
    
    <div class="container-fluid mt-3">
       <div class="deal-offer">
        <div class="row">
            <div class="col-lg-4 col-md-12">
                <div class="deal-desc">
                    <h4 class="deal-off-title">Deals of the day</h4>
                    <p>Avail daily discounted offers, hot deals<br>promo codes & coupons</p>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                <div class="dis-per">
                    <h6>Flat</h6>
                    <p>50%</p>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                <div class="dis-per">
                    <h6>Min</h6>
                    <p>30%</p>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                <div class="dis-per">
                    <h6>Under</h6>
                    <p>₹999</p>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                <div class="dis-per">
                    <h6>Under</h6>
                    <p>₹1599</p>
                </div>
            </div>
        </div>
    </div>
        <div class="budget-deal mt-3">
            <div class="title text-center">
                <span class="budget-deal-title" style="font-weight:700">Offers From Categories</span>
            </div>
            
            <div class="budget-deal-inner">
            <div class="row">
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 col-6">
                    <div class="sub-cat-img">
                        <img src="/public/assets/front-end/img/cat-img/C5.jpg" class="w-100" alt="">
                    </div>
                </div>
                
            </div>
            </div>
        </div>
        
        <div class="offer-selling mt-3">
            <div class="row">
                 <div class="col-sm-12">
                    <div class="owl-carousel owl-theme" id="offer-seller-banner">
                        <div class="item">
                            <a href="#" style="cursor: pointer;">
                        <img class="" style="width: 100%; border-radius:5px;height:296px;" src="/public/assets/front-end/img/ACBB1.jpg">
                    </a>
                        </div>
                        <div class="item">
                            <a href="#" style="cursor: pointer;">
                        <img class="" style="width: 100%; border-radius:5px;height:296px;" src="/public/assets/front-end/img/ACBB2.jpg">
                    </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="stock-soon mt-4 mb-3">
           <div class="d-flex justify-content-between">
                    <div class="title">
                        <span class="budget-deal-title" style="font-weight:700">Going Out Of Stock Soon</span>
                    </div>
                    <div class="latest-product-view-all" style="margin-right: 4px;">
                        <a class="text-capitalize view-all-text" href="#">
                            View all
                            <i class="czi-arrow-right-circle ml-1 mr-n1"></i>
                        </a>
                    </div>
                </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="owl-carousel owl-theme" id="stock-soon">
                            <div class="item">
                                <div class="product-single-hover product-card">
                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
<!--
                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                <span class="for-discoutn-value p-1 pl-2 pr-2">
                                    ON SALE
                                </span>
                            </div>
-->
                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                <a href="https://accezory.in/product/accezory-tan-artificial-leather-wallet-7jOPAf">
                                    <img src="https://accezory.in/storage/app/public/product/thumbnail/2022-07-12-62cdba21aec2a.png" onerror="this.src='https://accezory.in/public/assets/front-end/img/image-place-holder.png'" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                </a>
                            </div>
                        </div>
                        <div class="product-detail d-flex align-items-center">
                            <div>
                               <div class="brand-name">Accezory</div>
                                <div>
                                    <span class="flash-product-title">
                                        Men Brown Genuine Leather Wallet
                                    </span>
                                </div>
                                <div class="flash-product-review">
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <i class="sr-star czi-star-filled active"></i>
                                    <label class="badge-style2">
                                        ( 3 )
                                    </label>
                                </div>
                                <div>

                                </div>
                                <div class="flash-product-price">
                                    <span class="real-price" style="font-weight: 600">₹269.1</span>
                                    <strike class="strikr-price" style="color: #9b9b9b !important;">
                                        ₹299.0
                                    </strike>
                                    <span class="o-price" style="color: #E96A6A!important; font-weight: 600">
                                        65%
                                        Off
                                    </span>
                                </div>

                            </div>
                        </div>
                        <div class="add-to-link">
                <ul>
                    <li class="cart"><a class="cart-btn" href="#">Quick View</a></li>
                    <li>
                        <a href="#"><i class="czi-cart"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="czi-heart"></i></a>
                    </li>
                </ul>
            </div>
                    </div>
                            </div>
                            
                         </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
  {{-- Owl Carousel --}}
    <script src="{{asset('public/assets/front-end')}}/js/owl.carousel.min.js"></script>
   
   <script>
       $('#offer-seller-banner').owlCarousel({
           loop: true,
           autoplay: false,
           margin: 20,
           nav: false,
           navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
           dots: false,
           autoplayHoverPause: true,
           '{{session('
           direction ')}}': false,
           // center: true,
           responsive: {
               //X-Small
               0: {
                   items: 1
               },
               360: {
                   items: 1
               },
               375: {
                   items: 1
               },
               414: {
                   items: 1
               },
               //Small
               576: {
                   items: 1
               },
               //Medium
               768: {
                   items: 2
               },
               //Large
               992: {
                   items: 2
               },
               //Extra large
               1200: {
                   items: 2
               },
               //Extra extra large
               1400: {
                   items: 2
               }
           }
       })
       
       $('#stock-soon').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 3
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 6
                },
                //Extra extra large
                1400: {
                    items: 6
                }
            }
        })
   </script>
   
   
   
    <script>
        $(document).ready(function () {
            $('.card-header').click(function() {
                $('.card-header').removeClass('active');
                $(this).addClass('active');
            });

        });
        function get_categories(route) {
            $.get({
                url: route,
                dataType: 'json',
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (response) {
                    $('html,body').animate({scrollTop: $("#ajax-categories").offset().top}, 'slow');
                    $('#ajax-categories').html(response.view);
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        }
    </script>
@endpush
