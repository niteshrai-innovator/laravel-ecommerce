@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('Flash Deal Products'))

@push('css_or_js')
<meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}" />
<meta property="og:title" content="Deals of {{$web_config['name']->value}} " />
<meta property="og:url" content="{{env('APP_URL')}}">
<meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

<meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}" />
<meta property="twitter:title" content="Deals of {{$web_config['name']->value}}" />
<meta property="twitter:url" content="{{env('APP_URL')}}">
<meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">
<link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/new-css.css" />
<style>
    
    .countdown-card{
        position: absolute;
        top: 155px;
        left: 40%;
/*        transform: translateX(-50%);*/
    }
    
    .countdown-card .c-title{
        border-left: none !important;
        padding-left: 0px !important;
        color: #fff !important;
    }
    
    .cz-countdown-days, .cz-countdown-hours, .cz-countdown-minutes, .cz-countdown-seconds, .cz-countdown-value{
        color: #fff !important;
        background: transparent !important;
    }
    
    .brand-name{
        text-transform: uppercase;
        font-weight: 600;
    }
    
    .flash-product-title{
        font-size: 14px;
    }
    
    .flash-deal-page {
        border-left: 5px solid #1f2942;
        border-right: 5px solid #ff8000;
    }

    .product-card {
        padding-bottom: 0px;
        border: 1px solid transparent !important;
    }

    .product-card:hover:not(.card-static) {
        border-color: #ff8000 !important;
    }

    .product-detail {
        padding-left: 0px !important;
        padding-right: 0px !important;
        padding-bottom: 0px !important;
    }

    .flash-product-price {
        padding: 5px 15px 15px;
/*        background: #fae9d9;*/
    }

    .flash-price {
        color: #fff;
        margin: 0px;
        margin-bottom: 0px;
        font-size: 18px;
        margin-bottom: 5px;
        margin-left: 15px;
        margin-right: 15px;
        font-weight: 600;
        text-align: center;
        background: linear-gradient(to right, #f24e4e , #ff8000);
        border-radius: 3px;
    }

    .add-to-link {
/*        background: #fae9d9;*/
        left: 1px !important;
        right: 1px !important;
    }

    .flash_deal_title {
        font-weight: 700;
        font-size: 30px;

        text-transform: uppercase;
    }

    .cz-countdown {
        font-size: 18px;
    }


    .flex-center {
        display: flex;
        justify-content: space-between !important;
    }


    .flash_deal_product_details .flash-product-price {
        font-weight: 700;
        font-size: 25px;

        color: {
                {
                $web_config['primary_color']
            }
        }

        ;
    }

    .for-image {
        width: 100%;
        height: 200px;
    }

    @media (min-width: 360px) and (max-width: 575px) {
        .countdown-card .count-flex {
            display: block !important;
        }
    }



    /*
        @media (max-width: 600px) {
            .flash_deal_title {
                font-weight: 600;
                font-size: 26px;
            }

            .cz-countdown {
                font-size: 14px;
            }

            .for-image {

                height: 100px;
            }
        }

        @media (max-width: 768px) {
            .for-deal-tab {
                display: contents;
            }
            .flex-center{
                display: flex;
                justify-content: center !important;
            }
        }
*/

</style>
@endpush


@section('content')
@php($decimal_point_settings = \App\CPU\Helpers::get_business_settings('decimal_point_settings'))
<div class="flash-deal-page">
    <div class="for-banner rtl position-relative" style="text-align: {{Session::get('direction') === " rtl" ? 'right' : 'left' }};">

        <img class="d-block for-image" onerror="this.src='{{asset('storage/app/public/deal')}}/{{$deal['banner']}}'" src="{{asset('storage/app/public/deal')}}/{{$deal['banner']}}" alt="Shop Converse">

  <div class="row flex-center">
            <section class="col-lg-12 for-deal-tab countdown-card">
                @php($flash_deals=\App\Model\FlashDeal::with(['products.product.reviews'])->where(['status'=>1])->where(['deal_type'=>'flash_deal'])->whereDate('start_date','<=',date('Y-m-d'))->whereDate('end_date','>=',date('Y-m-d'))->first())
                    <div class="m-2 d-flex count-flex">
                            <span class="c-title">Ending In</span>
                            <div class="countdown-background">
                                <span class="cz-countdown d-flex justify-content-center align-items-center" data-countdown="{{isset($flash_deals)?date('m/d/Y',strtotime($flash_deals['end_date'])):''}} 11:59:00 PM">
                                    <span class="cz-countdown-days">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('d')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-hours">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('h')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-minutes">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('m')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-seconds">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('s')}}</span>
                                    </span>
                                </span>
                            </div>
                    </div>
            </section>
        </div>
   
    </div>
    <!-- Toolbar-->

    <!-- Products grid-->
    <div class="container-fluid pb-5 mt-5 rtl" style="text-align: {{Session::get('direction') === " rtl" ? 'right' : 'left' }};">
        <!--
        <div class="row">
            <section class="col-lg-12">
                <div class="row mt-4">
    
                    @if($discountPrice)
                        @foreach($deal->products as $dp)
                            @if (isset($dp->product))
                                <div class="col-xl-2 col-sm-3 col-6" style="margin-bottom: 10px">
                                    
                                    @include('web-views.partials._single-product',['product'=>$dp->product,'decimal_point_settings'=>$decimal_point_settings])
                                    
                                    
                                </div>
                            @endif
                        @endforeach
                    @endif
                </div>
            </section>
        </div>
-->
        <div class="row mt-4">
             @if($discountPrice)
                        @foreach($deal->products as $key=> $dp)
                            @if (isset($dp->product))
                                <div class="col-xl-2 col-lg-2 col-sm-6 col-md-4 col-6 mb-4">
                                    <div class="product-single-hover product-card">
                                        <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
                                            @if($dp->product->discount > 0)
                                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                                <span class="for-discoutn-value p-1 pl-2 pr-2">
                                                     @if ($dp->product->discount_type == 'percent')
                                                    {{round($dp->product->discount,$decimal_point_settings)}}%
                                                    @elseif($dp->product->discount_type =='flat')
                                                        {{\App\CPU\Helpers::currency_converter($product->discount)}}
                                                    @endif
                                                    {{\App\CPU\translate('off')}}
                                                </span>
                                            </div>
                                            @else
                                            <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index:99">
                                                <span class="for-discoutn-value p-1 pl-2 pr-2">New
                                                </span>
                                            </div>
                                            @endif
                                            <div class="d-flex d-block product-img" style="cursor: pointer;">
                                                <a href="{{route('product',$dp->product->slug)}}">
                                                    <img src="{{\App\CPU\ProductManager::product_image_path('thumbnail')}}/{{$dp->product['thumbnail']}}"
                                                    onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}" style="width: 100%;border-radius: 5px 5px 0px 0px;">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="flash-price">Flash Sale</div>
                                        <div class="product-detail pl-3 pr-3 pt-3 align-items-center">
                                            <div style="padding-left: 15px;padding-right: 15px">
                                                @php ($brands=\App\CPU\BrandManager::get_brands($dp->product['brand_id']))
                                               <div class="brand-name">{{@$brands[0]['name']}}</div>
                                                <div>
                                                    <span class="flash-product-title">
                                                         {{@$dp->product['name']}}
                                                    </span>
                                                </div>
                                                 @php($overallRating = \App\CPU\ProductManager::get_overall_rating($dp->product['reviews']))
                                                <div class="flash-product-review">
                                                    @for($inc=0;$inc<5;$inc++)
                                                        @if($inc<$overallRating[0])
                                                            <i class="sr-star czi-star-filled active"></i>
                                                        @else
                                                            <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                        @endif
                                                    @endfor
                                                    <label class="badge-style2">
                                                        ( {{$dp->product->reviews_count}})
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="flash-product-price">
                                                <span class="real-price" style="font-weight: 600">{{\App\CPU\Helpers::currency_converter(
                                                        $dp->product->unit_price-(\App\CPU\Helpers::get_product_discount($dp->product,$dp->product->unit_price))
                                                    )}}</span>
                                                     @if($dp->product->discount > 0)
                                                        <strike  class="strikr-price" style="color: #9b9b9b !important;">
                                                            {{\App\CPU\Helpers::currency_converter($dp->product->unit_price)}}
                                                        </strike>
                                                   @endif
                                                    @if($dp->product->discount > 0)
                                                        <span class="o-price" style="color: #E96A6A!important;font-size: 15px;font-weight: 600">
                                                             @if ($dp->product->discount_type == 'percent')
                                                            {{round($dp->product->discount,$decimal_point_settings)}}%
                                                            @elseif($dp->product->discount_type =='flat')
                                                                {{\App\CPU\Helpers::currency_converter($product->discount)}}
                                                            @endif
                                                            {{\App\CPU\translate('off')}}
                                                        </span>
                                                    @endif
                                            </div>
                                
                                
                                        </div>
                                         <form id="add-to-cart-form-{{$dp->product->id }}" class="mb-2">
                                        @csrf
                                        <input type="hidden" name="id" value="{{$dp->product->id }}">
                                        
                                        @if (count(json_decode($dp->product->colors)) > 0)
                                            @foreach (json_decode($dp->product->colors) as $key => $color)
                                                <input type="radio"  id="{{$dp->product->id}}-color-{{ $key }}"  name="color" value="{{ $color }}" @if($key == 0) checked @endif>
                                            @endforeach
                                        @else
                                              <input type="radio"  id="{{$dp->product->id}}-color-{{ $key }}"  name="color" value="#A52A2A" checked>
                                        @endif
                                        @if (count(json_decode($dp->product->choice_options)) > 0)
                                            @foreach (json_decode($dp->product->choice_options) as $key => $choice)
                                                @foreach ($choice->options as $key => $option)
                                                    <input type="radio" id="{{ $choice->name }}-{{ $option }}" name="{{ $choice->name }}" value="{{ $option }}"  @if($key == 0) checked @endif>
                                                @endforeach
                                            @endforeach
                                        @else
                                          <input type="radio" id="choice_1-s" name="choice_1-s" value="s" checked>
                                        @endif
                                        <input type="hidden" name="quantity" class="form-control input-number text-center cart-qty-field"  placeholder="1" value="1" min="1" max="100">
                                        <div class="add-to-link">
                                            <ul>
                                                <li class="cart"><a class="cart-btn" href="javascript: void(0)"  onclick="quickView('{{$dp->product->id}}')">Quick View</a></li>
                                                <li>
                                                    <a href="javascript: void(0)" onclick="addToCart('{{$dp->product->id}}')"><i class="czi-cart"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript: void(0)" onclick="addWishlist('{{$dp->product->id}}')"><i class="czi-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    </form>
                                    
                                    
                                </div>
                            @endif
                        @endforeach
                    @endif
           
        </div>
    </div>
</div>
@endsection

