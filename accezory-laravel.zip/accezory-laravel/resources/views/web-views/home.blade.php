@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('Welcome To').' '.$web_config['name']->value)


@push('css_or_js')
    <meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="og:title" content="Welcome To {{$web_config['name']->value}} Home"/>
    <meta property="og:url" content="{{env('APP_URL')}}">
    <meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="twitter:title" content="Welcome To {{$web_config['name']->value}} Home"/>
    <meta property="twitter:url" content="{{env('APP_URL')}}">
    <meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/home.css"/>
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/new-css.css"/>

    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.carousel.min.css"/>
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/owl.theme.default.min.css"/>
    <style>
        .product-card .product-img {
            overflow: hidden;
            height: 188px;
        }
        
        img.cat-img {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 350px;
            width: 90%;
            object-fit: cover;
            margin: auto;
            border-radius: 25px;
        }
    </style>
@endpush

@section('content')

@php($decimal_point_settings = \App\CPU\Helpers::get_business_settings('decimal_point_settings'))
 
   
   <div class="category-ul d-lg-none d-block">
       <div class="owl-carousel owl-theme" id="ul-carousel">
           <div class="item">
                   <a href="{{url('offers')}}">
                       <div class="ul-img">
                           <img 
                    onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                    src="{{asset('public/assets/front-end/img/offer_new.png')}}">
                       </div>
                       <div class="ul-desc">
                          Offers
                       </div>
                   </a>
               </div>
            @foreach($categories as $key=>$category)
                                    
                @if ($key<10)
               <div class="item">
                   <a href="{{route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])}}">
                       <div class="ul-img">
                           <img 
                    onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                    src="{{asset("storage/app/public/category/$category->icon")}}" alt="{{$category->name}}">
                       </div>
                       <div class="ul-desc">
                          {{$category->name}}
                       </div>
                   </a>
               </div>
               @endif
            
            @endforeach 
            
          
       </div>
   </div>
   
   
   
    <!-- Hero (Banners + Slider)-->
    <section class="bg-transparent mb-3">
        <div class="bg-slider">
            <div class="row ">
                <div class="col-12">
                    @include('web-views.partials._home-top-slider')
                </div>
            </div>
        </div>
    </section>

    {{--flash deal--}}
    @php($flash_deals=\App\Model\FlashDeal::with(['products'=>function($query){
        $query->with('product')->whereHas('product',function($q){
            $q->where('status',1);
        });
}])->where(['status'=>1])->where(['deal_type'=>'flash_deal'])->whereDate('start_date','<=',date('Y-m-d'))->whereDate('end_date','>=',date('Y-m-d'))->first())

    @if (isset($flash_deals))
    <div class="container-fluid countdown-div">
        <div class="row d-flex {{Session::get('direction') === "rtl" ? 'flex-row-reverse' : 'flex-row'}}">
            
            
            <div class="col-md-12 mt-2 countdown-card" >
                <div class="m-2 d-flex count-flex">
                        <div class="flash-deal-img title-img d-flex">
                            <img src="/public/assets/front-end/img/flash.jpg" alt="" class="flash_image">
                            <span class="for-feature-title flash_title">Flash Deal</span>
                            <a class="text-capitalize view-all-text view-all-text-2" href="{{route('flash-deals',[isset($flash_deals)?$flash_deals['id']:0])}}">
                                {{ \App\CPU\translate('view_all')}}
                                <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                            </a>
                        </div>
                        <div class="d-flex">
                           <span class="c-title">Ending In</span>
                            <div class="countdown-background">
                                <span class="cz-countdown d-flex justify-content-center align-items-center"
                                    data-countdown="{{isset($flash_deals)?date('m/d/Y',strtotime($flash_deals['end_date'])):''}} 11:59:00 PM">
                                    <span class="cz-countdown-days">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('d')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-hours">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('h')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-minutes">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('m')}}</span>
                                    </span>
                                    <span class="cz-countdown-value">:</span>
                                    <span class="cz-countdown-seconds">
                                        <span class="cz-countdown-value"></span><span class="me-s">{{ \App\CPU\translate('s')}}</span>
                                    </span>
                                </span>
                            </div>
                        </div>
                        <div class="flash-deal-view-all-web row d-flex ml-auto justify-content-{{Session::get('direction') === "rtl" ? 'start' : 'end'}}" style="{{Session::get('direction') === "rtl" ? 'margin-left: 2px;' : 'margin-right:2px;'}}">
                <a class="text-capitalize view-all-text" href="{{route('flash-deals',[isset($flash_deals)?$flash_deals['id']:0])}}">
                    {{ \App\CPU\translate('view_all')}}
                    <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                </a>
            </div>
                </div>
            </div>

            <div class="col-md-12 ">
                <div class="carousel-wrap">
                    <div class="owl-carousel owl-theme mt-2" id="flash-deal-slider">
                     @foreach($flash_deals->products as $key=>$deal)
                            @if( $deal->product)
                                    @include('web-views.partials._product-card-1',['product'=>$deal->product,'decimal_point_settings'=>$decimal_point_settings])
                            @endif
                        @endforeach
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

<!-- offer banner -->
    @php($one_banners = \App\Model\Banner::where('banner_type','One Banner')->where('published',1)->orderBy('id','desc')->latest()->get())
    @if (isset($one_banners))
   <div class="offer-banner mt-4">
       <div class="container-fluid">
           <div class="owl-carousel owl-theme" id="offer-slider">
                @foreach($one_banners as $one_banner)
                <div class="item">
                    <a href="{{$one_banner->url}}">
                        <img onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                src="{{asset('storage/app/public/banner')}}/{{$one_banner['photo']}}" alt="">
                    </a>
                </div>
                 @endforeach
            </div>
       </div>
   </div>
    @endif 
    {{--brands--}}
    
    <!-- hot categories -->
    <section class="container-fluid rtl mt-4">
        <!-- Heading-->
        <div class="section-header justify-content-center">
           
            <div class="hot-cat-img title-img">
                <!--<span><img src="/public/assets/front-end/img/title-img/hot_cate1.png" alt="Hot Category"></span>-->
                <!--<span style="width: 96%;"><img src="/public/assets/front-end/img/title-img/cat.png" alt="Hot Category"></span>-->
                 <span class="for-feature-title" style="text-align: center;font-size:35px !important; font-weight:700;width:100%;font-family:emoji !important;">Shop By Categories</span>
                 <span class="for-feature-title" style="text-align: center;font-size:20px !important;width:100%;font-family:emoji !important;">Discover our top category and pick the one you love the most</span>
                
            </div>
        </div>

        <div class="row mt-4">
            @php($subsubcategories=\App\Model\Category::where('position', 2)->where('home_status',1)->priority()->paginate(11))
            @foreach($subsubcategories as $key=>$category)
                        
            @if ($key<10)
            <div class="col-lg-4 col-xl-4 col-md-4 col-sm-4 item m-auto">
                <a href="{{route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])}}">
                    <img src="{{asset('storage/app/public/category/'.$category->icon)}}" class="cat-img" alt="{{$category->name}}">
                </a>
                <p style="text-align: center; font-size: 16px; padding: 6px; font-weight:600">{{$category->name}}</p>
            </div>
            @endif
            @endforeach
            <div class="col-sm-12" style="display:none;">
                
                <div class="cat-carousel-wrap">
                    <div class="owl-carousel owl-theme" id="cate-carousel">
                          @php($subsubcategories=\App\Model\Category::where('position', 2)->where('home_status',1)->priority()->paginate(11))
                        @foreach($subsubcategories as $key=>$category)
                                    
                            @if ($key<10)
                                <div class="item">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <a href="{{route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])}}">
                                                <div class="cate-card">
                                                    <div class="cat-img">
                                                        <img src="{{asset("storage/app/public/category/$category->icon")}}" alt="{{$category->name}}" style="height:200px;">
                                                    </div>
                                                </div>
                                            </a>
                                            
                                        </div>
                                    </div>
                                </div>
                            @endif
                        
                        @endforeach 
                        
                    </div>
                </div>
            </div>
        </div>

    </section>

    <!-- top trending -->
    @if ($featured_products->count() > 0 )
    <div class="container-fluid fetaured-products mt-4">
        <div class="row">
            <div class="col-md-12" >
                <div class="feature-product-title">
                   <img style="height:40px;width:40px;margin-top: -10px"  src="{{asset('public/assets/front-end/png/top-rated.png')}}" alt="">
                    <span style="font-size: 25px">TOP TRENDING</span>
                </div>
            </div>
            <div class="col-md-12 mt-4">
                <div class="feature-product">
                    <div class="carousel-wrap p-1">
                        <div class="owl-carousel owl-theme " id="featured_products_list">
                        @foreach($topRated as $key=>$top)
                    @if(@$top->product)
                       <div class="item">
                           <div class="featured-item" style="margin-bottom: 30px;">
                               <div class="product-single-hover product-card">
                                   <div class="inline_product clickable d-flex justify-content-center" style="cursor: pointer;">
                                        @if(@$top->product->discount > 0)
                                       <div class="d-flex" style="left:0px;top:0px;position: absolute;z-index: 99">
                                           <span class="for-discoutn-value p-1 pl-2 pr-2">
                                               @if ($top->product->discount_type == 'percent')
                                                            {{round($top->product->discount)}}%
                                                        @elseif($top->product->discount_type =='flat')
                                                            {{\App\CPU\Helpers::currency_converter($top->product->discount)}}
                                                        @endif {{\App\CPU\translate('off')}}
                                           </span>
                                       </div>
                                         @endif
                                       <div class="d-flex d-block product-img" style="cursor: pointer;background-color: #fff">
                                           <a href="{{route('product',$top->product->slug)}}">
                                               <img onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"  src="{{\App\CPU\ProductManager::product_image_path('thumbnail')}}/{{$top->product['thumbnail']}}" style="width: 100%;border-radius:5px;">
                                           </a>
                                       </div>
                                   </div>
                                    <div class="product-detail pl-3 pr-3 pt-3 d-flex align-items-center">
                                        <div>
                                            <div class="single-prod">
                                                <span class="flash-product-title">
                                                   {{\Illuminate\Support\Str::limit($top->product['name'],100)}}
                                                </span>
                                            </div>
                                              @php($top_overallRating = \App\CPU\ProductManager::get_overall_rating($top->product['reviews']))
                                            <div class="flash-product-review">
                                                @for($inc=0;$inc<=5;$inc++)
                                                    @if($inc<$top_overallRating[0])
                                                        <i class="sr-star czi-star-filled active"></i>
                                                    @else
                                                        <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                    @endif
                                                @endfor
                                               
                                                <label class="badge-style2">
                                                    ( {{$top->product->reviews_count}} )
                                                </label>
                                            </div>
                                            <div>
                                                
                                            </div>
                                            <div class="flash-product-price">
                                                @php($f_price =$top->product->unit_price-(\App\CPU\Helpers::get_product_discount($top->product,$top->product->unit_price)))
                                                <span class="real-price">{{\App\CPU\Helpers::currency_converter((int)$f_price)}} </span>
                                                  @if($top->product->discount > 0)
                                                          <strike class="strikr-price" style="color: #9b9b9b !important;">
                                                             {{\App\CPU\Helpers::currency_converter($top->product->unit_price)}}
                                                        </strike>
                                                    @endif
                                               
                                            </div>
                                        </div>
                                    </div>
                                    <form id="add-to-cart-form-{{ $top->product['id'] }}" class="mb-2">
                                        @csrf
                                        <input type="hidden" name="id" value="{{$top->product['id'] }}">
                                        
                                        @if (count(json_decode($top->product['colors'])) > 0)
                                            @foreach (json_decode($top->product['colors']) as $key => $color)
                                                <input type="radio"  id="{{$top->product['id']}}-color-{{ $key }}"  name="color" value="{{ $color }}" @if($key == 0) checked @endif>
                                            @endforeach
                                        @else
                                              <input type="radio"  id="{{$top->product['id']}}-color-{{ $key }}"  name="color" value="#A52A2A" checked>
                                        @endif
                                        @if (count(json_decode($top->product['choice_options'])) > 0)
                                            @foreach (json_decode($top->product['choice_options']) as $key => $choice)
                                                @foreach ($choice->options as $key => $option)
                                                    <input type="radio" id="{{ $choice->name }}-{{ $option }}" name="{{ $choice->name }}" value="{{ $option }}"  @if($key == 0) checked @endif>
                                                @endforeach
                                            @endforeach
                                        @else
                                          <input type="radio" id="choice_1-s" name="choice_1-s" value="s" checked>
                                        @endif
                                        <input type="hidden" name="quantity" class="form-control input-number text-center cart-qty-field"  placeholder="1" value="1" min="1" max="100">
                                    <div class="add-to-link">
                                        <ul>
                                            <li class="cart"><a class="cart-btn" href="javascript: void(0)"  onclick="quickView('{{$top->product['id']}}')">Quick View</a></li>
                                            <li>
                                                <a href="javascript: void(0)" onclick="addToCart({{ $top->product['id'] }})"><i class="czi-cart"></i></a>
                                            </li>
                                            <li>
                                                <a href="#" onclick="addWishlist('{{$top->product['id']}}')"><i class="czi-heart"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                    </form>
                               </div>


                           </div>
                       </div>
                         @endif
                       @endforeach
                     
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

@php($two_banners = \App\Model\Banner::where('banner_type','Two Banner')->where('published',1)->orderBy('id','desc')->latest()->first())
 @if (isset($two_banners))
    <div class="container-fluid sec-banner rtl mb-3 mt-4">
        <div class="row">
            <div class="col-12 pl-0 pr-0">
                <a href="{{$two_banners->url}}" style="cursor: pointer;">
                    <img class="d-block" style="width: 100%;border-radius: 5px;height: 350px;object-fit:cover;object-position: top" onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                src="{{asset('storage/app/public/banner')}}/{{$two_banners['photo']}}">
                </a>
            </div>
        </div>
    </div>
 @endif 
    <!-- best selling section -->
     @php($best_banners = \App\Model\Banner::where('banner_type','Best Selling Banner')->where('published',1)->orderBy('id','desc')->latest()->get())
     @if(count($best_banners)>0)
    <section class="best-seling mt-4">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="seling-title">
                        <div class="hot-cat-img title-img" style="text-align: center;">
                            <!--<span style="width: 100%;"><img src="/public/assets/front-end/img/title-img/tranding-removebg-preview.png" alt="Top Tranding"></span>-->
                            <span class="for-feature-title" style="text-align: center;font-size:35px !important; font-weight:700;width:100%;font-family:emoji !important;">Trending Offers</span>
                            <span class="for-feature-title" style="text-align: center;font-size:20px !important;width:100%;font-family:emoji !important;">All Your Favorites at an  Unbelievable Price</span>

                        </div>
                        
                        {{--<img style="height:40px;width:40px;margin-top: -10px;" src="{{asset('public/assets/front-end/png/best sellings.png')}}" alt="">
                        <span style="margin-left:10px;font-size: 25px;text-transform: uppercase;font-weight: 700;"> {{ \App\CPU\translate('Budget buy')}}</span>--}}
                    </div>
                </div>
               
                @if (isset($best_banners))
                <div class="row col-lg-12 col-xl-12 col-md-12 col-sm-12 mt-3 row">
                    {{--<div class="owl-carousel owl-theme" id="best-seller-banner">
                         @foreach($best_banners as $best_banner)
                        <div class="item">
                            <a href="{{$best_banner->url}}" style="cursor: pointer;">
                                <img class="" style="width: 100%; border-radius:5px;height:296px;"  onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                src="{{asset('storage/app/public/banner')}}/{{$best_banner['photo']}}">
                            </a>
                        </div>
                         @endforeach
                    </div>--}}
                    @foreach($best_banners as $best_banner)
                    <div class="col-lg-3 col-xl-3 col-md-3 col-sm-3 item mt-3">
                        <a href="{{$best_banner->url}}" style="cursor: pointer;">
                            <img class="" style="width: 100%; border-radius:5px;height:400px;"  onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                            src="{{asset('storage/app/public/banner')}}/{{$best_banner['photo']}}">
                        </a>
                    </div>
                    @endforeach
                </div>
                 @endif 
               {{-- <div class="col-lg-6 col-xl-6 col-md-4 col-sm-12 mt-3">
                    <div class="owl-carousel owl-theme" id="best-seller">
                        @foreach($bestSellProduct as $key=>$bestSell)
                        @if($bestSell->product && $key<3)
                        <div class="item">
                            <div class="sel-card product-card" style="box-shadow: 0px 0px 5px rgba(0, 113, 220, 0.15); border-radius:5px;background: #fff" >
                                  @if($bestSell->product->discount > 0)
                                <div class="d-flex">
                                    
                                    <span class="for-discoutn-value p-1 pl-2 pr-2" style="border-radius:5px 0px;">
                                        @if ($bestSell->product->discount_type == 'percent')
                                            {{round($bestSell->product->discount)}}%
                                        @elseif($bestSell->product->discount_type =='flat')
                                            {{\App\CPU\Helpers::currency_converter($bestSell->product->discount)}}
                                        @endif {{\App\CPU\translate('off')}}
                                    </span>
                                 
                                </div>
                                    @endif
                                <div class="sel-card-inner">

                                    <div class="best-selleing-image product-img">
                                        <a class="d-block d-flex justify-content-center" style="width:100%;height:100%;" href="{{route('product',$bestSell->product->slug)}}">
                                            <img style="width: 125px;height: 125px;" onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                                        src="{{\App\CPU\ProductManager::product_image_path('thumbnail')}}/{{$bestSell->product['thumbnail']}}" alt="Product">
                                        </a>
                                    </div>
                                    <div class="best-selling-details product-detail pl-3 pr-3 pt-3 pb-4 d-flex align-items-center">
                                        <div>
                                            <div class="single-prod">
                                                <span class="flash-product-title">
                                                        {{\Illuminate\Support\Str::limit($bestSell->product['name'],100)}}
                                                </span>
                                            </div>
                                               @php($bestSell_overallRating = \App\CPU\ProductManager::get_overall_rating($bestSell->product['reviews']))
                                                
                                            <div class="flash-product-review">
                                               @for($inc=0;$inc<5;$inc++)
                                                    @if($inc<$bestSell_overallRating[0])
                                                        <i class="sr-star czi-star-filled active"></i>
                                                    @else
                                                        <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                    @endif
                                                @endfor
                                                <label class="badge-style2">
                                                    (  {{$bestSell->product->reviews_count}}  )
                                                </label>
                                            </div>
                                            <div>
                                                
                                            </div>
                                            <div class="flash-product-price">
                                                @php($db_price =$bestSell->product->unit_price-(\App\CPU\Helpers::get_product_discount($bestSell->product,$bestSell->product->unit_price)))
                                                <span class="real-price"> {{\App\CPU\Helpers::currency_converter((int)$db_price)}} </span>
                                                @if($bestSell->product->discount > 0)
                                                <strike class="strikr-price" style="color: #9b9b9b !important;">
                                                   {{\App\CPU\Helpers::currency_converter($bestSell->product->unit_price)}}
                                                </strike> 
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                     <form id="add-to-cart-form-{{$bestSell->product['id']}}" class="mb-2">
                                    @csrf
                                    <input type="hidden" name="id" value="{{$bestSell->product['id']}}">
                                    
                                    @if (count(json_decode($bestSell->product['colors'])) > 0)
                                        @foreach (json_decode($bestSell->product['colors']) as $key => $color)
                                            <input type="radio"  id="{{$bestSell->product['id']}}-color-{{ $key }}"  name="color" value="{{ $color }}" @if($key == 0) checked @endif>
                                        @endforeach
                                    @else
                                          <input type="radio"  id="{{$bestSell->product['id']}}-color-{{ $key }}"  name="color" value="#A52A2A" checked>
                                    @endif
                                    @if (count(json_decode($bestSell->product['choice_options'])) > 0)
                                        @foreach (json_decode($bestSell->product['choice_options']) as $key => $choice)
                                            @foreach ($choice->options as $key => $option)
                                                <input type="radio" id="{{ $choice->name }}-{{ $option }}" name="{{ $choice->name }}" value="{{ $option }}"  @if($key == 0) checked @endif>
                                            @endforeach
                                        @endforeach
                                    @else
                                      <input type="radio" id="choice_1-s" name="choice_1-s" value="s" checked>
                                    @endif
                                    <input type="hidden" name="quantity" class="form-control input-number text-center cart-qty-field"  placeholder="1" value="1" min="1" max="100">
                                    <div class="add-to-link">
                                        <ul>
                                            <li class="cart"><a class="cart-btn" href="javascript: void(0)"  onclick="quickView('{{$bestSell->product['id']}}')">Quick View</a></li>
                                            <li>
                                                <a href="javascript: void(0)" onclick="addToCart({{$bestSell->product['id']}})"><i class="czi-cart"></i></a>
                                            </li>
                                            <li>
                                                <a href="javascript: void(0)" onclick="addWishlist('{{$bestSell->product['id']}}')"><i class="czi-heart"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @endif
                            @endforeach
                      
                    </div>--}}
                </div>
            </div>
        </div>

    </section>
    @endif
    {{--featured deal--}}
    @php($featured_deals=\App\Model\FlashDeal::with(['products'=>function($query_one){
        $query_one->with('product.reviews')->whereHas('product',function($query_two){
            $query_two->active();
        });
    }])
    ->whereDate('start_date', '<=', date('Y-m-d'))->whereDate('end_date', '>=', date('Y-m-d'))
    ->where(['status'=>1])->where(['deal_type'=>'feature_deal'])
    ->first())

    @if(isset($featured_deals))
        <section class="container-fluid featured_deal rtl mb-2 mt-2">
            <div class="row" style="background: {{$web_config['primary_color']}};padding:5px;padding-bottom: 25px; border-radius:5px;">
                <div class="col-12 pb-2" >
                    @if (count($featured_deals->products)>0)
                        <a class="text-capitalize mt-2 mt-md-0 {{Session::get('direction') === "rtl" ? 'float-left' : 'float-right'}}" href="{{route('products',['data_from'=>'featured_deal'])}}"
                            style="color: white !important;{{Session::get('direction') === "rtl" ? 'margin-left: 21px;' : 'margin-right: 21px;'}}">
                            {{ \App\CPU\translate('view_all')}}
                            <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                        </a>
                    @endif
                </div>
                <div class="col-xl-3 col-md-4 d-flex align-items-center justify-content-center right">
                    <div class="m-4">
                        <span class="featured_deal_title"
                            style="padding-top: 12px">{{ \App\CPU\translate('Daily Deals')}}</span>
                        <br>

                        <span style="color: #fd8808;text-align: left !important;font-size: 19px;">{{ \App\CPU\translate('See the latest deals and exciting new offers ')}}!</span>

                    </div>

                </div>

                <div class="col-xl-9 col-md-8 d-flex align-items-center justify-content-center {{Session::get('direction') === "rtl" ? 'pl-4' : 'pr-4'}}">
                    <div class="owl-carousel owl-theme" id="web-feature-deal-slider">
                        @foreach($featured_deals->products as $key=>$product)
                            @include('web-views.partials._feature-deal-product',['product'=>$product->product, 'decimal_point_settings'=>$decimal_point_settings])
                        @endforeach
                    </div>
                </div>
            </div>
        </section>
    @endif
    
    @php($main_section_banner = \App\Model\Banner::where('banner_type','Main Section Banner')->where('published',1)->orderBy('id','desc')->latest()->first())
    @if (isset($main_section_banner))
    <div class="container-fluid sec-banner rtl mb-3 mt-4">
        <div class="row" >
            <div class="col-12 pl-0 pr-0">
                <a href="{{$main_section_banner->url}}"
                    style="cursor: pointer;">
                    <img class="d-block footer_banner_img" style="width: 100%;border-radius: 5px;height: auto !important;"
                            onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                            src="{{asset('storage/app/public/banner')}}/{{$main_section_banner['photo']}}">
                </a>
            </div>
        </div>
    </div>
    @endif
    
    <!-- on sale section -->
    
      @php($featured_deals=\App\Model\FlashDeal::with(['products'=>function($query_one){
                    $query_one->with('product.reviews')->whereHas('product',function($query_two){
                        $query_two->where('status',1);
                    });
                }])->where(['status'=>1])->where(['deal_type'=>'feature_deal'])->first());
    @if($bestSellProduct !=null)
    @if(count($bestSellProduct) >0)

    <div class="container-fluid rtl">
        <div class="col-sm-12 d-flex justify-content-between">
            <div class="seling-title">
                <img style="height:40px;width:40px;margin-top: -10px;" src="{{asset('public/assets/front-end/png/best sellings.png')}}" alt="">
                <span style="margin-left:10px;font-size: 25px;text-transform: uppercase;font-weight: 700;"> {{ \App\CPU\translate('Top picks for you')}}</span>
            </div>
            <div class="latest-product-view-all" style="margin-right: 4px;">
                <a class="text-capitalize view-all-text"
                   href="{{route('products',['data_from'=>'best-selling'])}}">
                    {{ \App\CPU\translate('view_all')}}
                    <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                </a>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-xl-12 col-md-12 mt-2 pl-0 pr-0">
                <div class="onsale-product-margin">
                    <div class="row mt-2">
                        @foreach($bestSellProduct as $item)
                        <div class="col-xl-2 col-lg-2 col-sm-6 col-md-4 col-6 mb-4">
                            <div style="margin:2px;">
                                <div class="product-single-hover product-card">
                                    <div class=" inline_product clickable d-flex justify-content-center" style="cursor: pointer;background:#ffffff;">
                                        <div class="d-flex" style="left:0px;top:2px;position: absolute;z-index: 99">
                                            <span class="for-discoutn-value p-1 pl-2 pr-2">
                                                ON SALE
                                            </span>
                                        </div>
                                        <div class="d-flex d-block product-img" style="cursor: pointer;">
                                            <a href="{{route('product',$item->product->slug)}}">
                                                <img  style="width: 100%;border-radius: 5px 5px 0px 0px;" onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                                        src="{{\App\CPU\ProductManager::product_image_path('thumbnail')}}/{{$item->product->thumbnail}}" >
                                            </a>
                                        </div>
                                    </div>
                                    <div class="product-detail pl-3 pr-3 pt-3 d-flex align-items-center">
                                        <div>
                                            <div class="single-prod">
                                                <span class="flash-product-title">
                                                   {{$item->product->name}}
                                                </span>
                                            </div>
                                                 @php($overallRating = \App\CPU\ProductManager::get_overall_rating($item->product->reviews))
                                            <div class="flash-product-review">
                                                @for($inc=0;$inc<5;$inc++)
                                                    @if($inc<$overallRating[0])
                                                        <i class="sr-star czi-star-filled active"></i>
                                                    @else
                                                        <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                    @endif
                                                @endfor
                                                <label class="badge-style">
                                                    (  {{$item->product->reviews_count}})
                                                </label>
                                            </div>
                                            <div>
                                            </div>
                                            <div class="flash-product-price">
                                                @php($it_price =$item->product->unit_price-(\App\CPU\Helpers::get_product_discount($item->product,$item->product->unit_price)))
                                               <span class="real-price">{{\App\CPU\Helpers::currency_converter((int)$it_price)}} </span>
                                                @if($item->product->discount > 0) 
                                                <strike class="strikr-price" style="color: #9b9b9b !important;">{{\App\CPU\Helpers::currency_converter($item->product->unit_price)}}</strike>
                                                 @endif
                                                @if($item->product->discount > 0)
                                                <span class="o-price" style="color: #E96A6A!important;">  
                                                @if ($item->product->discount_type == 'percent')
                                                    {{round($item->product->discount,$decimal_point_settings)}}%
                                                @elseif($item->product->discount_type =='flat')
                                                    {{\App\CPU\Helpers::currency_converter($item->product->discount)}}
                                                @endif {{\App\CPU\translate('off')}}
                                                </span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <form id="add-to-cart-form-{{$item->product->id}}" class="mb-2">
                                        @csrf
                                        <input type="hidden" name="id" value="{{$item->product->id}}">
                                        
                                        @if (count(json_decode($item->product->colors)) > 0)
                                            @foreach (json_decode($item->product->colors) as $key => $color)
                                                <input type="radio"  id="{{$item->product->id}}-color-{{ $key }}"  name="color" value="{{ $color }}" @if($key == 0) checked @endif>
                                            @endforeach
                                        @else
                                              <input type="radio"  id="{{$item->product->id}}-color-{{ $key }}"  name="color" value="#A52A2A" checked>
                                        @endif
                                        @if (count(json_decode($item->product->choice_options)) > 0)
                                            @foreach (json_decode($item->product->choice_options) as $key => $choice)
                                                @foreach ($choice->options as $key => $option)
                                                    <input type="radio" id="{{ $choice->name }}-{{ $option }}" name="{{ $choice->name }}" value="{{ $option }}"  @if($key == 0) checked @endif>
                                                @endforeach
                                            @endforeach
                                        @else
                                          <input type="radio" id="choice_1-s" name="choice_1-s" value="s" checked>
                                        @endif
                                        <input type="hidden" name="quantity" class="form-control input-number text-center cart-qty-field"  placeholder="1" value="1" min="1" max="100">
                                        <div class="add-to-link">
                                            <ul>
                                                <li class="cart"><a class="cart-btn" href="javascript: void(0)"  onclick="quickView('{{$item->product->id}}')">Quick View</a></li>
                                                <li>
                                                    <a href="javascript: void(0)" onclick="addToCart({{$item->product->id}})"><i class="czi-cart"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript: void(0)" onclick="addWishlist('{{$item->product->id}}')"><i class="czi-heart"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </form>
                                </div>


                            </div>
                        </div>
                        @endforeach
                     
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
    @endif
    
    @php($footer_section_banners = \App\Model\Banner::where('banner_type','Footer Banner')->where('published',1)->orderBy('id','desc')->latest()->get())
    @if (isset($footer_section_banners))
      <div class="container-fluid mt-4">
          <div class="owl-carousel owl-theme" id="dob-banner">
              @foreach($footer_section_banners as $footer_section_banner)
              <div class="item">
                  <a href="{{$footer_section_banner->url}}" style="cursor: pointer;">
                      <img class="" style="width: 100%; border-radius:5px;height:auto;" onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                src="{{asset('storage/app/public/banner')}}/{{$footer_section_banner['photo']}}">
                  </a>
              </div>
              @endforeach
          </div>
      </div>
    @endif  
   <!--- recently added section --->
    <div class="container-fluid rtl">
        <div class="row mt-4">
            {{-- Latest products --}}
            <div class="col-xl-12 col-md-12 mt-2 pl-0 pr-0">
                <div class="latest-product-margin">
                    <div class="d-flex justify-content-between">
                        <div class="title" style="text-align: center;">
                            <span class="for-feature-title" style="text-align: center;font-size:25px !important; font-weight:700">New Arrivals</span>
                        </div>
                        <div class="latest-product-view-all" style="margin-right: 4px;">
                            <a class="text-capitalize view-all-text"
                               href="{{route('products',['data_from'=>'latest'])}}">
                                {{ \App\CPU\translate('view_all')}}
                                <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div class="row mt-2">
                         @foreach($latest_products as $product)
                          @include('web-views.partials._single-product',['product'=>$product,'decimal_point_settings'=>$decimal_point_settings])
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Categorized product --}}
    @foreach($home_categories as $cat_key=> $category)
    @if($category['parent_id'] ==0)
        <section class="container-fluid rtl mb-3 mt-4">
            <!-- Heading-->
            <div class="bags-luggage">
                <div class="flex-between">
                    <div class="category-product-view-title" >
                        <span class="for-feature-title {{Session::get('direction') === "rtl" ? 'float-right' : 'float-left'}}" 
                                style="font-weight: 700;font-size: 25px;{{Session::get('direction') === "rtl" ? 'text-align:right;' : 'text-align:left;'}}">
                                  {{Str::limit($category['name'],30)}}
                        </span>
                    </div>
                    <div class="category-product-view-all" >
                        <a class="text-capitalize view-all-text "
                            href="{{route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])}}">{{ \App\CPU\translate('view_all')}}
                            <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'}}"></i>
                        </a>
                        
                    </div>
                </div>
    
                <div class="row mt-2 mb-3 d-flex justify-content-between">
                    <div class="col-md-4 col-12 pr-3 d-none d-md-block">
                        <a href="{{route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])}}"
                            style="cursor: pointer;">
                             <img class="" style="width: 100%; border-radius:5px;height: 274px;"
                                  onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                  src="{{asset('storage/app/public/category')}}/{{$category['icon']}}">
                         </a>
                    </div>
                     <div class="col-md-8 col-12 ">

                         <div class="owl-carousel owl-theme" id="bags-luggage">
                             @foreach($category['products'] as $key=>$product)
                                @if ($key<4)
                                     @include('web-views.partials._category-single-product',['product'=>$product,'decimal_point_settings'=>$decimal_point_settings])
                                @endif
                            @endforeach
                            
                         </div>
                    </div>
                            
                        
                </div>
            </div>
        </section>
        @endif
    @endforeach

    @php($footer_offers_banners = \App\Model\Banner::where('banner_type','Footer Offers Banner')->where('published',1)->orderBy('id','desc')->latest()->get())
    @if (isset($footer_offers_banners))        
        <div class="footer-offer-banner">
            <div class="container-fluid">
                <div class="owl-carousel owl-theme" id="footer-offer">
                     @foreach($footer_offers_banners as $footer_offers_banner)
                    <div class="item">
                        <a href="{{$footer_offers_banner->url}}">
                            <img onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                src="{{asset('storage/app/public/banner')}}/{{$footer_offers_banner['photo']}}" style="border-radius: 5px" alt="">
                        </a>
                    </div>
                     @endforeach
                </div>
            </div>
        </div>
    @endif  
        {{--delivery type --}}

    <div class="container-fluid rtl mb-3">
        <div class="row shipping-policy-web" style="margin-right: 0px; margin-left:0px;">
            <div class="col-md-3 col-sm-6 col-6 d-flex justify-content-center">
                <div class="shipping-method-system" >
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="{{asset("public/assets/front-end/png/delivery.png")}}"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        {{ \App\CPU\translate('Fast Delivery all accross the country')}}
                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="{{asset("public/assets/front-end/png/Payment.png")}}"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        {{ \App\CPU\translate('Safe Payment')}}
                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="{{asset("public/assets/front-end/png/money.png")}}"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        {{ \App\CPU\translate('7 Days Return Policy')}}
                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="{{asset("public/assets/front-end/png/Genuine.png")}}"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        {{ \App\CPU\translate('100% Authentic Products')}}
                    </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
@endsection

@push('script')
    {{-- Owl Carousel --}}
    <script src="{{asset('public/assets/front-end')}}/js/owl.carousel.min.js"></script>

    <script>
        $('#ul-carousel').owlCarousel({
            loop: false,
            autoplay: false,
            // margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: false,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 4
                },
                360: {
                    items: 4
                },
                375: {
                    items: 4
                },
                414: {
                    items: 5
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 6
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 6
                },
                //Extra extra large
                1400: {
                    items: 6
                }
            }
        })
        
        $('#flash-deal-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 3
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 6
                },
                //Extra extra large
                1400: {
                    items: 6
                }
            }
        })
        
        $('#offer-slider').owlCarousel({
            loop: true,
            autoplay: true,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                414: {
                    items: 1
                },
                //Small
                576: {
                    items: 1
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 4
                }
            }
        })
        
        $('#cate-carousel').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 3
                },
                //Medium
                768: {
                    items: 4
                },
                //Large
                992: {
                    items: 5
                },
                //Extra large
                1200: {
                    items: 5
                },
                //Extra extra large
                1400: {
                    items: 6
                }
            }
        })
        
        $('#best-seller').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 1
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 3
                },
                //Extra extra large
                1400: {
                    items: 3
                }
            }
        })
        $('#best-seller-banner').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                414: {
                    items: 1
                },
                //Small
                576: {
                    items: 1
                },
                //Medium
                768: {
                    items: 4
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 5
                }
            }
        })

        $('#web-feature-deal-slider').owlCarousel({
            loop: false,
            autoplay: true,
            margin: 5,
            nav: false,
            //navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 2
                }
            }
        })
        
        $('#featured-slider').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: true,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 1
                },
                //Small
                576: {
                    items: 1
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 1
                },
                //Extra extra large
                1400: {
                    items: 1
                }
            }
        })
        
        $('#dob-banner').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 1
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 2
                }
            }
        })
        
        $('#week-deal-s').owlCarousel({
            loop:true,
            margin:10,
            nav:false,
            dots: true,
            autoplay: true,
            autoplayTimeout: 2000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        })
        
        $('#bags-luggage').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 3
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 4
                }
            }
        })
        
        $('#footer-offer').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 1
                },
                //Small
                576: {
                    items: 1
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 3
                },
                //Extra extra large
                1400: {
                    items: 3
                }
            }
        })

        $('#new-arrivals-product').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: true,
            navText: ["<i class='czi-arrow-{{Session::get('direction') === "rtl" ? 'right' : 'left'}}'></i>", "<i class='czi-arrow-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 4
                }
            }
        })
    </script>
<script>
     $('#featured_products_list').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: false,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '{{session('direction')}}': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 2
                },
                375: {
                    items: 2
                },
                414: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 3
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 6
                },
                //Extra extra large
                1400: {
                    items: 6
                }
            }
        })
</script>
    <script>
        $('#brands-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 10,
            nav: false,
            '{{session('direction')}}': true,
            //navText: ["<i class='czi-arrow-left'></i>","<i class='czi-arrow-right'></i>"],
            dots: true,
            autoplayHoverPause: true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 3
                },
                375: {
                    items: 3
                },
                540: {
                    items: 4
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 7
                },
                //Large
                992: {
                    items: 9
                },
                //Extra large
                1200: {
                    items: 11
                },
                //Extra extra large
                1400: {
                    items: 12
                }
            }
        })
    </script>

    <script>
        $('#category-slider, #top-seller-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: false,
            // navText: ["<i class='czi-arrow-left'></i>","<i class='czi-arrow-right'></i>"],
            dots: true,
            autoplayHoverPause: true,
            '{{session('direction')}}': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 3
                },
                375: {
                    items: 3
                },
                540: {
                    items: 4
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 6
                },
                //Large
                992: {
                    items: 8
                },
                //Extra large
                1200: {
                    items: 10
                },
                //Extra extra large
                1400: {
                    items: 11
                }
            }
        })
    </script>
@endpush

