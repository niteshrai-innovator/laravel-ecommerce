@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('Checkout'))

@push('css_or_js')
   
   
    <style>
         body{
        overflow-x: hidden !important;
    }
    
    .apply-btn {
        border: none;
        background: #ff8000;
        text-transform: uppercase;
        color: #fff;
        font-weight: 600;
        width: 20%;
        font-size: 14px;
    }
    
    .cart_information{
        border-radius: 0px;
    }
    
    .feature_header{
        padding: 10px 16px 10px;
        background-color: #fff;
        margin-bottom: 2px;
    }
    
    .shop-name{
        padding-bottom: 10px;
        border-bottom: 1px solid #efefef;
    }
    
    .product-cart{
        border-bottom: 1px solid #efefef;
        padding: 20px 0px;
    }
    
    .shop-name p{
        margin: 0px;
        font-size: 15px;
    }
    
    .shop-name a{
        font-size: 15px;
        text-transform: uppercase;
        font-weight: 600;
    }
    
    .cart-p-detail p{
        margin: 0px;
        font-size: 16px;
    }
    
    .qty-select select{
        width: 75px;
        height: 30px;
        background: transparent;
        border: 1px solid #dae1e7;
        border-radius: 2px;
        color: #7d879c;
    }
    
    .bill-collapse{
        display: flow-root;
        text-align: right;
        color: #ff8000 !important;
        margin-left: 10px;
    }
    
    .bill-collapse:after {
        font-family: 'FontAwesome';  
        content: "\f056";
    }
    .bill-collapse.collapsed:after {
        content: "\f055"; 
    }
    
    .bill-box{
        color: #ff8000;
        background-color: #f8e5d2;
        padding: 10px;
        margin-top: 5px;
    }
    
    .tax_value, .tax_title{
        font-size: 15px !important;
    }
    
    .tax_value{
        font-weight: 600;
    }
    
    .shiping-time{
        font-size: 14px;
        color: #7d879c;
    }
    
    .remove-ul li a{
        color: #7d879c !important;
    }
    
    .remove-ul li span{
        font-size: 14px;
    }
    
    .remove-ul li i{
        font-size: 18px;
        margin-right: 5px;
    }
    
    .remove-ul li:first-child{
        padding-right: 20px;
        border-right: 2px solid #eeeeee;
    }
    
    .remove-ul li:last-child{
        padding-left: 20px;
    }
    
    .sub-total {
        font-size: 20px;
        font-weight: 600;
        padding-top: 10px;
    }
    
    .sub-total p{
        margin-bottom: 0px;
        margin-right: 5px;
    }
    
    .shiping-time-mobile{
        display: none !important;
    }
    .inputqty{
        width:44px;
        text-align:center;
    }
    
    @media (min-width: 360px) and (max-width: 767px){
        .container-fluid{
            padding-left: 0px;
            padding-right: 0px;
        }
        .steps{
            display:none;
        }
        
        .product-cart{
            padding-bottom: 0px !important;
        }
        
        .cart_information{
            padding: 16px !important;
        }
        
        .shiping-time-mobile{
            display: flex !important;
            margin-bottom: 20px;
        }
        
        .shiping-time-web{
            display: none !important;
        }
        
        .remove-ul li{
            border-top: 2px solid #eeeeee;
            padding: 10px 0px;
        }
        
        .remove-ul li:first-child {
            padding-right: 20px;
            border-right: 2px solid #eeeeee;
            flex: 0 0 50%;
            text-align: center;
            }
        
        .remove-ul li:last-child{
            flex: 0 0 50%;
        }
        
        .remove-ul{
            margin-top: 0px !important;
        }
        
        .total-ul{
            background: #fff;
            padding: 10px 10px;
            justify-content: space-between;
            border-top: 1px solid #efefef;
        }
        
        .total-ul li{
            flex: 0 0 50%;
        }
        
        .total-ul li .place-order-btn{
            text-transform: capitalize !important;
        }
        
        .m-footer{
            display: none;
        }
    }
        
        .feature_header .title {
            font-size: 22px;
            font-weight: 700;
            text-transform: uppercase;
            padding-top: 5px;
        }
        
        .steps{
            width: 30%;
        }
        
        .step-item{
            display: flex;
            text-align: left;
        }
        
        .step-progress{
            flex: 0 0 35%;
            background: none !important;
        }
        
        .step-label{
            flex: 0 0 65%;
            padding-top: 0px;
            text-transform: uppercase;
            color: #ff8000;
        }
        
        .step-count{
            top: -2px;
            text-align: center;
            font-size: 16px !important;
            text-align: center;
            font-weight: 500 !important;
            color: #ff8000 !important;
            border: 2px solid #ff8000;
            width: 25px;
            height: 25px;
            line-height: 22px;
        }
        
        .step-item.dis .step-label{
            color: #7d879c !important;
        }
        
        .step-item.dis .step-count{
            color: #7d879c !important;
            border-color: #7d879c !important;
        }
        
        .ship-title{
            font-size: 18px;
            font-weight: 600;
            color: #000;
        }
        
        .t-price{
            border-top: 1px solid #efefef;
            border-bottom: 1px solid #efefef;
            padding: 10px 0px;
        }
        
        .place-order-btn{
            display: none !important;
        }
        
        .payment-btn {
            text-transform: uppercase;
            background: #ff8000 !important;
            border-color: #ff8000 !important;
            font-weight: 600;
            flex: 0 0 30%;
            color: #fff !important; 
        }
        
        .payment-btn:hover{
            background: none !important;
            color: #ff8000 !important;
        }

/*
        .for-container {
            width: 91%;
            border: 1px solid #D8D8D8;
            margin-top: 3%;
            margin-bottom: 3%;
        }

        .for-padding {
            padding: 3%;
        }
*/


    </style>
    
     <style>
      

        .product-qty span {
            font-size: 14px;
            color: #6A6A6A;
        }

        .font-nameA {

            display: inline-block;
            margin-top: 5px !important;
            font-size: 13px !important;
            color: #030303;
        }

        .font-name {
            font-weight: 600;
            font-size: 15px;
            padding-bottom: 6px;
            color: #030303;
        }

        .modal-footer {
            border-top: none;
        }

        .cz-sidebar-body h3:hover + .divider-role {
            border-bottom: 3px solid {{$web_config['primary_color']}} !important;
            transition: .2s ease-in-out;
        }

        label {
            font-size: 15px;
            margin-bottom: 8px;
            color: #030303;

        }

        .nav-pills .nav-link.active {
            box-shadow: none;
            color: #ffffff !important;
        }

        .modal-header {
            border-bottom: none;
        }

        .nav-pills .nav-link {
            padding-top: .575rem;
            padding-bottom: .575rem;
            background-color: #ffffff;
            color: #050b16 !important;
            font-size: .9375rem;
            border: 1px solid #e4dfdf;
        }

        .nav-pills .nav-link :hover {
            padding-top: .575rem;
            padding-bottom: .575rem;
            background-color: #ffffff;
            color: #050b16 !important;
            font-size: .9375rem;
            border: 1px solid #e4dfdf;
        }

        .nav-pills .nav-link.active, .nav-pills .show > .nav-link {
            color: #fff;
            background-color: {{$web_config['primary_color']}};
        }

        .iconHad {
            color: {{$web_config['primary_color']}};
            padding: 4px;
        }

        .iconSp {
            margin-top: 0.70rem;
        }

        .fa-lg {
            padding: 4px;
        }

        .fa-trash {
            color: #FF4D4D;
        }

        .namHad {
            color: #030303;
            position: absolute;
            padding-{{Session::get('direction') === "rtl" ? 'right' : 'left'}}: 13px;
            padding-top: 8px;
        }

        .donate-now {
            list-style-type: none;
            margin: 25px 0 0 0;
            padding: 0;
        }

        .donate-now li {
            float: left;
            margin: {{Session::get('direction') === "rtl" ? '0 0 0 5px' : '0 5px 0 0'}};
            width: 100px;
            height: 40px;
            position: relative;
            padding: 22px;
            text-align: center;
        }

        .donate-now label,
        .donate-now input {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
        }

        .donate-now input[type="radio"] {
            opacity: 0.01;
            z-index: 100;
        }

        .donate-now input[type="radio"]:checked + label,
        .Checked + label {
            background: {{$web_config['primary_color']}};
            color: white !important;
            border-radius: 7px;
        }

        .donate-now label {
            padding: 5px;
            border: 1px solid #CCC;
            cursor: pointer;
            z-index: 90;
        }

        .donate-now label:hover {
            background: #DDD;
        }

        #edit{
            cursor: pointer;
        }
        .pac-container { z-index: 100000 !important; }

        @media (max-width: 600px) {
            .sidebar_heading h1 {
                text-align: center;
                color: aliceblue;
                padding-bottom: 17px;
                font-size: 19px;
            }
        }
        #location_map_canvas{
            height: 100%;
        }
        @media only screen and (max-width: 768px) {
            /* For mobile phones: */
            #location_map_canvas{
                height: 200px;
            }
        }
    </style>

    <meta property="og:image" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="og:title" content="About {{$web_config['name']->value}} "/>
    <meta property="og:url" content="{{env('APP_URL')}}">
    <meta property="og:description" content="{!! substr($web_config['about']->value,0,100) !!}">

    <meta property="twitter:card" content="{{asset('storage/app/public/company')}}/{{$web_config['web_logo']->value}}"/>
    <meta property="twitter:title" content="about {{$web_config['name']->value}}"/>
    <meta property="twitter:url" content="{{env('APP_URL')}}">
    <meta property="twitter:description" content="{!! substr($web_config['about']->value,0,100) !!}">
    <link rel="stylesheet" href="{{asset('public/assets/front-end')}}/css/shop-cart.css"/>

@endpush

@section('content')


  <div class="container-fluid pb-5 mb-2 rtl">
   
  <div class="feature_header justify-content-between d-flex">
      <div class="title" style="color: #6e6868;">Shipping And Billing Address</div>
              <div class="d-md-none d-block" style="font-size: 15px; width: 95px;">Step 2 <span style="color: #7d879c;font-size: 15px !important;text-transform: capitalize !important;font-weight: 500 !important">of 3</span></div>
      <div class="steps steps-light pt-2 pb-2 ">
          <a class="step-item active " href="https://accezory.in/checkout-details">
              <div class="step-progress">
                  <span class="step-count">1</span>
              </div>
              <div class="step-label">
                  Summary
              </div>
          </a>
          <a class="step-item active current" href="#">
              <div class="step-progress">
                  <span class="step-count">2</span>
              </div>
              <div class="step-label">
                  Address
              </div>
          </a>
          <a class="step-item dis" href="#">
              <div class="step-progress">
                  <span class="step-count">3</span>
              </div>
              <div class="step-label">
                  Payment
              </div>
          </a>
      </div>
  </div>

<!-- Grid-->
@php($shippingMethod=\App\CPU\Helpers::get_business_settings('shipping_method'))
@php($cart=\App\Model\Cart::where(['customer_id' => auth('customer')->id()])->get()->groupBy('cart_group_id'))
@php($cart_count=\App\Model\Cart::where(['customer_id' => auth('customer')->id()])->get())
 @php($total_shipping_cost=0)
@php($shipping_cost=\App\CPU\CartManager::get_shipping_cost())
@php($total_shipping_cost=$shipping_cost)
<div class="row">
    <!-- List of items-->
    <section class="col-lg-8">
            @php($shipping_addresses=\App\Model\ShippingAddress::where('customer_id',auth('customer')->id())->where('is_billing',0)->get())
            <div class="cart_information mb-3">
                 <div class="ship-title mt-2 mb-2">
                    <span>Shipping Address</span>
                </div>
                <div style="font-size: 15px;" class="justify-content-between  d-flex">
                    <div> Hey! Welcome back - <span>{{auth('customer')->user()->f_name}} {{auth('customer')->user()->l_name}} - {{auth('customer')->user()->email}} </span>  </div>
                    @if(count($shipping_addresses)>1)
                    <div>  <button class="btn btn-primary place-order-btn" style="padding: 3px;font-size: 12px;margin-left: 10px;" data-toggle="modal" data-target="#exampleChnageModal"> Change </button>  </div>
                    @endif
                </div>
                <div>
                     @php($default_location=\App\CPU\Helpers::get_business_settings('default_location'))
                    <input type="hidden" id="physical_product" name="physical_product" value="{{ $physical_product ? 'yes':'no'}}">
                            <div class="card-body" style="padding: 0!important;margin-bottom: 10px;">
                                <ul class="list-group">
                                    @foreach($shipping_addresses as $key=>$address)
                                        <li class="list-group-item mb-2 mt-2"
                                            style="cursor: pointer;border: 1px solid #e1e9ef; @if($key!=0)display:none;@endif" id="sh-{{$address['id']}}" >
                                            <span class="checkmark" ></span>
                                            <label class="badge" style="background: {{$web_config['primary_color']}}; color:white !important;">{{$address['address_type']}}</label>
                                            <span style="font-size: 14px; text-transform: uppercase;">
                                                <b>{{$address['contact_person_name']}}</b><br>
                                                {{$address['address']}}, {{$address['city']}}, {{$address['zip']}}, 
                                                <b> Phone Number: </b>{{$address['phone']}}
                                            </span>
                                        </li>
                                    @endforeach
                                </ul>
                                <a style="padding: 3px;font-size: 12px;margin-left: 10px;color: #4d7e7c !important;cursor: pointer;" class="pb-3" data-toggle="modal" data-target="#exampleModal">  <i class="fa fa-plus" aria-hidden="true" id="add_new_address" style="">  </i>Add a New Address </a>
                            </div>
                        <!--<div>-->
                        <!--    <span class="btn btn-primary place-order-btn mb-3" style="width: 14%;font-size: 14px;text-transform: none;padding: 6px;">Use this Address</span>-->
                        <!--</div>-->
                        
                </div>
               
               @php($sub_totals=0)
                @php($total_taxs=0)
                @foreach($cart as $group_key=>$group)
                @foreach($group as $cart_key=>$cartItem)
                
                    @php($sub_totals+=((int)($cartItem['price']-$cartItem['discount']))*$cartItem['quantity'])
                    @php($total_taxs+=$cartItem['tax']*$cartItem['quantity'])
                @endforeach
                @endforeach
              <div class="t-price d-flex justify-content-between">
               <p style="margin:0px" class="ship-title"><i class="navbar-tool-icon czi-cart"></i> <span>Order Summary</span></p>
               <p style="font-weight: 600;margin: 0px" class="d-md-block d-none"><span style="color: #7d879c;font-size: 14px;">Total ({{count($cart_count)}} items)</span><br><span id="final">{{\App\CPU\Helpers::currency_converter((int)$sub_totals)}}</span></p>
               </div>
                <input type="checkbox" id="same_as_shipping_address" onclick="hide_billingAddress()" name="same_as_shipping_address" class="form-check-input d-none" checked>
                @php($sub_total=0)
                @php($total_tax=0)
                @foreach($cart as $group_key=>$group)
                @foreach($group as $cart_key=>$cartItem)
                   @php($minimum_order=\App\Model\Product::select('minimum_order_qty','shipping_cost','multiply_qty')->find($cartItem['product_id']))
                <div class="product-cart">
                    <div class="row">
                        <div class="col-md-2 col-sm-4 col-4">
                            <div class="cart-img">
                                <img onerror="this.src='https://demo.accezory.in/public/assets/front-end/img/image-place-holder.png'"
                                src="{{\App\CPU\ProductManager::product_image_path('thumbnail')}}/{{$cartItem['thumbnail']}}" alt="Product">
                            </div>
                            <div class="qty-select mt-2 d-md-none d-block">
                                    <input type="button" onclick="decrementValue('{{$cartItem['id']}}')" value="-" />
                                    <input type="text" name="quantity[{{ $cartItem['id'] }}]" value="{{$cartItem['quantity']}}" class="inputqty" id="cartQuantity{{$cartItem['id']}}" min="{{ $minimum_order->minimum_order_qty ?? 1 }}" />
                                    <input type="button" onclick="incrementValue('{{$cartItem['id']}}')" value="+" />
                                
                                </div>
                        </div>
                        <div class="col-md-5 col-sm-8 col-8">
                            <div class="cart-p-detail">
                                <p><span style="font-weight: 600">ACCEZORY</span> {{$cartItem['name']}}</p>
                                <div class="c-price d-flex">
                                    <div style="font-size: 18px;color: #000;font-weight: 600">{{ \App\CPU\Helpers::currency_converter((int)($cartItem['price']-$cartItem['discount'])) }}</div>
                                    @if($cartItem['discount'] > 0)
                                       <strike style="font-size: 17px!important;color: #9b9b9b !important;margin-left: 10px;">
                                            {{\App\CPU\Helpers::currency_converter($cartItem['price'])}}
                                        </strike>
                                    @endif
                                    
                                    
                                </div>
                                <div style="color: #7d879c;font-size: 14px">
                                    @foreach(json_decode($cartItem['variations'],true) as $key1 =>$variation)
                                     {{$key1}} : <span>{{$variation}}</span>
                                    @endforeach
                                </div>
                                <div class="qty-select mt-2 d-none d-md-block">
                                    
                                   
                                        <input type="button" onclick="decrementValue('{{$cartItem['id']}}')" value="-" />
                                    <input type="text" name="quantity[{{ $cartItem['id'] }}]" value="{{$cartItem['quantity']}}" class="inputqty" id="cartQuantity{{$cartItem['id']}}" min="{{ $minimum_order->minimum_order_qty ?? 1 }}" />
                                    <input type="button" onclick="incrementValue('{{$cartItem['id']}}')" value="+" />
                                
                                        {{--<select name="quantity[{{ $cartItem['id'] }}]" id="cartQuantity{{$cartItem['id']}}"
                                                onchange="updateCartQuantity('{{$cartItem['id']}}')">
                                            @for ($i = $minimum_order_limit??1; $i <= 10; $i++)
                                                <option
                                                    value="{{$i}}" {{$cartItem['quantity'] == $i?'selected':''}}>
                                                    Qty {{$i}}
                                                </option>
                                            @endfor
                                        </select> --}}
                                        {{--<input style="width: 75px;" type="number" name="quantity[{{ $cartItem['id'] }}]" id="cartQuantity{{$cartItem['id']}}"
                                        onchange="updateCartQuantity('{{ $minimum_order->minimum_order_qty }}', '{{$cartItem['id']}}')" min="{{ $minimum_order->minimum_order_qty ?? 1 }}" value="{{$cartItem['quantity']}}">--}}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12 col-12">
                         <div class="shiping-time shiping-time-mobile justify-content-end d-flex">
                                <img src="/public/assets/front-end/png/d-truck.png" alt=""> <span style="margin-left: 5px;">Delivery by</span> <span style="color: #000 !important;margin-left: 5px">23rd Sep</span> <span style="padding: 0px 5px;">|</span> <span style="color: #4BB543 !important;font-weight:600;">FREE</span>
                            </div>
                          <div class="tax-box">
                           <div class="d-flex justify-content-between">
                           <p style="font-weight: 600;font-size: 14px" class="d-md-none d-block">Price (Inclusive of GST)</p>
                           <div class="d-flex ml-auto">
                            <span style="font-size: 16px;color: #000;font-weight: 600"> 
                             {{ \App\CPU\Helpers::currency_converter($all_price =(int)(($cartItem['price']-$cartItem['discount'])*$cartItem['quantity'])) }}</span> 
                               <a class="collapsed bill-collapse" data-toggle="collapse" href="#collapseOne{{$cart_key}}" style="font-size: 15px">
                                Details
                            </a>
                            </div>
                            
                            </div>
                            <div id="collapseOne{{$cart_key}}" class="collapse">
                                <div class="bill-box">
                                    <div class="d-flex justify-content-between">
                                        <span class="tax_title">Price</span>
                                        <span class="tax_value">
                                            @php($gst_amount = ($all_price*18)/100)
                                           {{ \App\CPU\Helpers::currency_converter($all_price-$gst_amount) }}
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <span class="tax_title">GST(18%)</span>
                                        <span class="tax_value">
                                             {{ \App\CPU\Helpers::currency_converter($gst_amount) }}
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <span class="tax_title">Final Price</span>
                                        <span class="tax_value">
                                              {{ \App\CPU\Helpers::currency_converter($all_price) }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="shiping-time shiping-time-web justify-content-end d-flex mt-2">
                                <img src="/public/assets/front-end/png/d-truck.png" alt=""> <span style="margin-left: 5px;">Typecally Delivers Between 3-5 Days*</span>
                            </div>
                            <div class="shiping-time shiping-time-web justify-content-end d-flex mt-2">
                                 <span style="margin-left: 5px;">Delivery Charges:  </span>
                                   @if($minimum_order->shipping_cost ==0.00)
                                    <span style="color: #4BB543 !important; "> FREE</span>
                                  @else
                                    @if($minimum_order->multiply_qty==1)
                                        <span style="color: #4BB543 !important; "> {{\App\CPU\Helpers::currency_converter($minimum_order->shipping_cost*$cartItem['quantity'])}}</span>
                                    @else
                                        <span style="color: #4BB543 !important; "> {{\App\CPU\Helpers::currency_converter($minimum_order->shipping_cost)}}</span>
                                    @endif
                                   
                                  @endif
                            </div>
                            <ul class="nav remove-ul justify-content-end mt-3">
                                <li>
                                    <a href="javascript: void(0)" onclick="removeFromCarts({{ $cartItem['id'] }})">
                                        <i class="fa fa-trash-o" aria-hidden="true"></i> <span>Remove</span>
                                    </a>
                                </li>
                                 <li>
                                    <a href="javascript: void(0)" onclick="addWishlist('{{$cartItem['id']}}')">
                                        <i class="fa fa-heart-o" aria-hidden="true"></i> <span>Save to wishlist</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                 @php($sub_total+=($cartItem['price']-$cartItem['discount'])*$cartItem['quantity'])
                 @php($total_tax+=$cartItem['tax']*$cartItem['quantity'])
                @endforeach
                @endforeach
                
                
                
                <div class="d-flex justify-content-between">
                   <p class="mt-3" style="margin-bottom: 0px;">Order confirmation email will be sent to <strong>{{auth('customer')->user()->email}}</strong></p>
                    {{--<button class="btn btn-block payment-btn mt-3" type="button" onclick="proceed_to_next()">Make Payment</button>--}}
                </div>
                
                {{--<div class="total-box d-block d-md-none">
                    <ul class="total-ul nav fixed-bottom">
                        <li>
                            <div style="font-size: 14px;color: #7d879c">Payable Amount</div>
                            <div style="font-size: 18px; font-weight: 600" id="fprice">₹{{\App\CPU\Helpers::currency_converter($sub_total+$total_tax)}}</div>
                        </li>
                        <li>
                            <button class="btn btn-primary btn-block payment-btn" type="button" onclick="proceed_to_next()"> Place Order</button>
                        </li>
                    </ul>
                </div>--}}
        </div>
    </section>
      <div class="modal fade rtl" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-md-12"><h5 class="modal-title font-name ">{{\App\CPU\translate('add_new_address')}}</h5></div>
                    </div>
                </div>
                <div class="modal-body">
                    <form action="{{route('address-store')}}" method="post">
                        @csrf

                        <div class="row">
                            <div class="col-md-6" style="display: flex">
                                <!-- Nav pills -->

                                <ul class="donate-now">
                                    <li>
                                        <input type="radio" id="a25" name="addressAs" value="permanent"/>
                                        <label for="a25" class="component">{{\App\CPU\translate('permanent')}}</label>
                                    </li>
                                    <li>
                                        <input type="radio" id="a50" name="addressAs" value="home"/>
                                        <label for="a50" class="component">{{\App\CPU\translate('Home')}}</label>
                                    </li>
                                    <li>
                                        <input type="radio" id="a75" name="addressAs" value="office" checked="checked"/>
                                        <label for="a75" class="component">{{\App\CPU\translate('Office')}}</label>
                                    </li>

                                </ul>
                            </div>

                            <div class="col-md-6" style="display: flex">
                                <!-- Nav pills -->

                                <ul class="donate-now">
                                    <li>
                                        <input type="radio" name="is_billing" id="b25" value="0"/>
                                        <label for="b25" class="billing_component">{{\App\CPU\translate('shipping')}}</label>
                                    </li>
                                    <!--<li>-->
                                    <!--    <input type="radio" name="is_billing" id="b50" value="1"/>-->
                                    <!--    <label for="b50" class="billing_component">{{\App\CPU\translate('billing')}}</label>-->
                                    <!--</li>-->
                                </ul>
                            </div>
                        </div>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div id="home" class="container tab-pane active"><br>


                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="name">{{\App\CPU\translate('contact_person_name')}}</label>
                                        <input class="form-control" type="text" id="name" name="name" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="firstName">{{\App\CPU\translate('Phone')}}</label>
                                        <input class="form-control" type="text" id="phone" name="phone" required>
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="address-city">{{\App\CPU\translate('City')}}</label>
                                        <input class="form-control" type="text" id="address-city" name="city" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="zip">{{\App\CPU\translate('zip_code')}}</label>
                                        <input class="form-control" type="number" id="zip" name="zip" required>
                                    </div>
                                </div>
                                
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="address">{{\App\CPU\translate('address')}}</label>
                                        
                                        <textarea class="form-control" id="address"
                                                            type="text"  name="address" required></textarea>
                                    </div>
                                    @php($default_location=\App\CPU\Helpers::get_business_settings('default_location'))
                                    <div class="form-group col-md-12">
                                        <input id="pac-input" class="controls rounded" style="height: 3em;width:fit-content;" title="{{\App\CPU\translate('search_your_location_here')}}" type="text" placeholder="{{\App\CPU\translate('search_here')}}"/>
                                        <div style="height: 200px;" id="location_map_canvas"></div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="latitude"
                                name="latitude" class="form-control d-inline"
                                placeholder="Ex : -94.22213" value="{{$default_location?$default_location['lat']:0}}" required readonly>
                            <input type="hidden"
                                name="longitude" class="form-control"
                                placeholder="Ex : 103.344322" id="longitude" value="{{$default_location?$default_location['lng']:0}}" required readonly>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{\App\CPU\translate('close')}}</button>
                                <button type="submit" class="btn btn-primary">{{\App\CPU\translate('Add')}} {{\App\CPU\translate('Informations')}}  </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
      <div class="modal fade rtl" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};" id="exampleChnageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-md-12"><h5 class="modal-title font-name ">Choose Address</h5></div>
                    </div>
                </div>
                <div class="modal-body">
                     <form method="post" action="" id="address-form">

                            <div class="card-body" style="padding: 0!important;margin-bottom: 10px;">
                                <ul class="list-group">
                                    @foreach($shipping_addresses as $key=>$address)
                                        <li class="list-group-item mb-2 mt-2"
                                            style="cursor: pointer;/*background: rgba(245,245,245,0.51);*/border: 1px solid #e1e9ef;"
                                            onclick="$('#shs-{{$address['id']}}').prop( 'checked', true )">
                                            <input type="radio" name="shipping_method_id"
                                                   id="shs-{{$address['id']}}"
                                                   value="{{$address['id']}}" {{$key==0?'checked':''}}>
                                            <span class="checkmark"
                                                  style="margin-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}: 10px"></span>
                                            <label class="badge"
                                                   style="background: {{$web_config['primary_color']}}; color:white !important;">{{$address['address_type']}}</label>
                                            <span style="font-size: 14px; text-transform: uppercase;">
                                                <b>{{$address['contact_person_name']}}</b><br>
                                                {{$address['address']}}, {{$address['city']}}, {{$address['zip']}}, 
                                                <b> Phone Number: </b>{{$address['phone']}}
                                            </span>
                                            {{--<hr>
                                            <span>{{ \App\CPU\translate('contact_person_name')}}: {{$address['contact_person_name']}}</span><br>
                                            <span>{{ \App\CPU\translate('address')}} : {{$address['address']}}, {{$address['city']}}, {{$address['zip']}}.</span>--}}
                                        </li>
                                    @endforeach
                                   
                                </ul>
                                 <span class="btn btn-primary place-order-btn mb-3" style="width: 20%;font-size: 14px;text-transform: none;padding: 6px;" onclick="useThisAddress()">Use this Address</span>
                            </div>
                        </form>
                        
                </div>
            </div>

        </div>
    </div>
    <!-- Sidebar-->
    @include('web-views.partials._order-summary')
      </div>




@endsection
@push('script')

<script type="text/javascript">
function incrementValue(id)
{
    var value = parseInt(document.getElementById('cartQuantity'+id).value, 10);
    value = isNaN(value) ? 0 : value;
    if(value<10){
        value++;
            document.getElementById('cartQuantity'+id).value = value;
            updateCartQuantitys(id);
    }
}
function decrementValue(id)
{
    var value = parseInt(document.getElementById('cartQuantity'+id).value, 10);
    value = isNaN(value) ? 0 : value;
    if(value>1){
        value--;
            document.getElementById('cartQuantity'+id).value = value;
    
            updateCartQuantitys(id);        
    }

}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key={{\App\CPU\Helpers::get_business_settings('map_api_key')}}&libraries=places&v=3.49"></script>
    <script>
        function initAutocomplete() {
            var myLatLng = {
                lat: {{$default_location?$default_location['lat']:'-33.8688'}},
                lng: {{$default_location?$default_location['lng']:'151.2195'}}
            };

            const map = new google.maps.Map(document.getElementById("location_map_canvas"), {
                center: {
                    lat: {{$default_location?$default_location['lat']:'-33.8688'}},
                    lng: {{$default_location?$default_location['lng']:'151.2195'}}
                },
                zoom: 13,
                mapTypeId: "roadmap",
            });

            var marker = new google.maps.Marker({
                position: myLatLng,
                map: map,
            });

            marker.setMap(map);
            var geocoder = geocoder = new google.maps.Geocoder();
            google.maps.event.addListener(map, 'click', function (mapsMouseEvent) {
                var coordinates = JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2);
                var coordinates = JSON.parse(coordinates);
                var latlng = new google.maps.LatLng(coordinates['lat'], coordinates['lng']);
                marker.setPosition(latlng);
                map.panTo(latlng);

                document.getElementById('latitude').value = coordinates['lat'];
                document.getElementById('longitude').value = coordinates['lng'];

                geocoder.geocode({'latLng': latlng}, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[1]) {
                            document.getElementById('address').value = results[1].formatted_address;
                            console.log(results[1].formatted_address);
                        }
                    }
                });
            });

            // Create the search box and link it to the UI element.
            const input = document.getElementById("pac-input");
            const searchBox = new google.maps.places.SearchBox(input);
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(input);
            // Bias the SearchBox results towards current map's viewport.
            map.addListener("bounds_changed", () => {
                searchBox.setBounds(map.getBounds());
            });
            let markers = [];
            // Listen for the event fired when the user selects a prediction and retrieve
            // more details for that place.
            searchBox.addListener("places_changed", () => {
                const places = searchBox.getPlaces();

                if (places.length == 0) {
                    return;
                }
                // Clear out the old markers.
                markers.forEach((marker) => {
                    marker.setMap(null);
                });
                markers = [];
                // For each place, get the icon, name and location.
                const bounds = new google.maps.LatLngBounds();
                places.forEach((place) => {
                    if (!place.geometry || !place.geometry.location) {
                        console.log("Returned place contains no geometry");
                        return;
                    }
                    var mrkr = new google.maps.Marker({
                        map,
                        title: place.name,
                        position: place.geometry.location,
                    });

                    google.maps.event.addListener(mrkr, "click", function (event) {
                        document.getElementById('latitude').value = this.position.lat();
                        document.getElementById('longitude').value = this.position.lng();

                    });

                    markers.push(mrkr);

                    if (place.geometry.viewport) {
                        // Only geocodes have viewport.
                        bounds.union(place.geometry.viewport);
                    } else {
                        bounds.extend(place.geometry.location);
                    }
                });
                map.fitBounds(bounds);
            });
        };
        $(document).on('ready', function () {
            initAutocomplete();

        });

        $(document).on("keydown", "input", function (e) {
            if (e.which == 13) e.preventDefault();
        });
    </script>

    <script>
        function initAutocompleteBilling() {
            var myLatLng = {
                lat: {{$default_location?$default_location['lat']:'-33.8688'}},
                lng: {{$default_location?$default_location['lng']:'151.2195'}}
            };

            const map = new google.maps.Map(document.getElementById("location_map_canvas_billing"), {
                center: {
                    lat: {{$default_location?$default_location['lat']:'-33.8688'}},
                    lng: {{$default_location?$default_location['lng']:'151.2195'}}
                },
                zoom: 13,
                mapTypeId: "roadmap",
            });

            var marker = new google.maps.Marker({
                position: myLatLng,
                map: map,
            });

            marker.setMap(map);
            var geocoder = geocoder = new google.maps.Geocoder();
            google.maps.event.addListener(map, 'click', function (mapsMouseEvent) {
                var coordinates = JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2);
                var coordinates = JSON.parse(coordinates);
                var latlng = new google.maps.LatLng(coordinates['lat'], coordinates['lng']);
                marker.setPosition(latlng);
                map.panTo(latlng);

                document.getElementById('billing_latitude').value = coordinates['lat'];
                document.getElementById('billing_longitude').value = coordinates['lng'];

                geocoder.geocode({'latLng': latlng}, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[1]) {
                            document.getElementById('billing_address').value = results[1].formatted_address;
                            console.log(results[1].formatted_address);
                        }
                    }
                });
            });

            // Create the search box and link it to the UI element.
            const input = document.getElementById("pac-input-billing");
            const searchBox = new google.maps.places.SearchBox(input);
            map.controls[google.maps.ControlPosition.TOP_CENTER].push(input);
            // Bias the SearchBox results towards current map's viewport.
            map.addListener("bounds_changed", () => {
                searchBox.setBounds(map.getBounds());
            });
            let markers = [];
            // Listen for the event fired when the user selects a prediction and retrieve
            // more details for that place.
            searchBox.addListener("places_changed", () => {
                const places = searchBox.getPlaces();

                if (places.length == 0) {
                    return;
                }
                // Clear out the old markers.
                markers.forEach((marker) => {
                    marker.setMap(null);
                });
                markers = [];
                // For each place, get the icon, name and location.
                const bounds = new google.maps.LatLngBounds();
                places.forEach((place) => {
                    if (!place.geometry || !place.geometry.location) {
                        console.log("Returned place contains no geometry");
                        return;
                    }
                    var mrkr = new google.maps.Marker({
                        map,
                        title: place.name,
                        position: place.geometry.location,
                    });

                    google.maps.event.addListener(mrkr, "click", function (event) {
                        document.getElementById('billing_latitude').value = this.position.lat();
                        document.getElementById('billing_longitude').value = this.position.lng();

                    });

                    markers.push(mrkr);

                    if (place.geometry.viewport) {
                        // Only geocodes have viewport.
                        bounds.union(place.geometry.viewport);
                    } else {
                        bounds.extend(place.geometry.location);
                    }
                });
                map.fitBounds(bounds);
            });
        };
        $(document).on('ready', function () {
            initAutocompleteBilling();

        });

        $(document).on("keydown", "input", function (e) {
            if (e.which == 13) e.preventDefault();
        });
    </script>
 <script>
        function proceed_to_next() {
            let physical_product = $('#physical_product').val();

            if(physical_product === 'yes') {
                var billing_addresss_same_shipping = $('#same_as_shipping_address').is(":checked");

                let allAreFilled = true;
                document.getElementById("address-form").querySelectorAll("[required]").forEach(function (i) {
                    if (!allAreFilled) return;
                    if (!i.value) allAreFilled = false;
                    if (i.type === "radio") {
                        let radioValueCheck = false;
                        document.getElementById("address-form").querySelectorAll(`[name=${i.name}]`).forEach(function (r) {
                            if (r.checked) radioValueCheck = true;
                        });
                        allAreFilled = radioValueCheck;
                    }
                });

                //billing address saved
                let allAreFilled_shipping = true;

                if (billing_addresss_same_shipping != true) {

                    document.getElementById("billing-address-form").querySelectorAll("[required]").forEach(function (i) {
                        if (!allAreFilled_shipping) return;
                        if (!i.value) allAreFilled_shipping = false;
                        if (i.type === "radio") {
                            let radioValueCheck = false;
                            document.getElementById("billing-address-form").querySelectorAll(`[name=${i.name}]`).forEach(function (r) {
                                if (r.checked) radioValueCheck = true;
                            });
                            allAreFilled_shipping = radioValueCheck;
                        }
                    });
                }
            }else {
                var billing_addresss_same_shipping = false;
            }
            
            // console.log(physical_product);
            // console.log(physical_product === 'yes' ? $('#address-form').serialize() : null);
            // // console.log($('#billing-address-form').serialize());
            // console.log(billing_addresss_same_shipping);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('customer.choose-shipping-address')}}',
                // dataType: 'json',
                data: {
                    physical_product: physical_product,
                    shipping: physical_product === 'yes' ? $('#address-form').serialize() : null,
                    // billing: $('#billing-address-form').serialize(),
                    billing_addresss_same_shipping: billing_addresss_same_shipping
                },
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (data) {
                    if (data.errors) {
                        for (var i = 0; i < data.errors.length; i++) {
                            toastr.error(data.errors[i].message, {
                                CloseButton: true,
                                ProgressBar: true
                            });
                        }
                    } else {
                        location.href = '{{route('checkout-payment')}}';
                    }
                },
                complete: function () {
                    $('#loading').hide();
                },
                error: function () {
                    toastr.error('{{\App\CPU\translate('Please fill all required fields of shipping/billing address')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });


        }
        
        function useThisAddress(){
            $("#exampleChnageModal").modal('hide');
              @foreach($shipping_addresses as $key=>$address)
                $("#sh-{{$address['id']}}").hide();
              @endforeach
            var add_id = $('[name="shipping_method_id"]:checked').val();
            $("#sh-"+add_id).show();
        }
    </script>
    @endpush
